//
//  RegisterViewController.swift
//  VK
//
//  Created by Павел Власов on 08.10.2021.
//

import UIKit

class RegisterViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let gradient = CAGradientLayer()  //создание градиента
        gradient.colors = [UIColor.systemPurple.cgColor,
                           UIColor.systemGreen.cgColor]  //цвета
        gradient.locations = [0, 1]  //где цвета
        gradient.startPoint = CGPoint.zero  //начало
        gradient.endPoint = CGPoint(x: 0, y: 1)  //конец
        gradient.frame = self.view.bounds
        gradient.zPosition = 0  //какой слой вью
        self.view.layer.addSublayer(gradient)  //рисование
        
        scrollView.layer.zPosition = 1      //чтобы элементы вывести поверх градиента
        loginTextField.layer.zPosition = 1
        passwordTextField.layer.zPosition = 1
        loginButton.layer.zPosition = 1
        imageView.layer.zPosition = 1
        loginLabel.layer.zPosition = 1
        noPasswordButton.layer.zPosition = 1
        passwordLabel.layer.zPosition = 1
        loginButton.layer.borderColor = UIColor.black.cgColor  //обводка кнопки
        loginButton.layer.borderWidth = 4  //ширина обводки
        loginButton.layer.cornerRadius = 12  //закругление
        loginButton.layer.backgroundColor = UIColor.black.cgColor  //заливка кнопки
        
        
        
        addShadow(view: loginTextField)  //добавление тени объектам
        addShadow(view: passwordTextField)
        addShadow(view: loginButton)
        
        
        
        
    }
    
    func addShadow(view: UIView) { //функция для добавления тени
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = CGSize(width: 10, height: 10)
        view.layer.shadowRadius = 5
        view.layer.shadowOpacity = 1
    }
    
    @IBOutlet weak var scrollView: UIScrollView!        //аутлеты для акт. элементов
    @IBOutlet weak var loginTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    @IBOutlet weak var imageView: UIScrollView!  //аутлеты для выставления слоев
    @IBOutlet weak var loginLabel: UILabel!
    @IBOutlet weak var noPasswordButton: UIButton!
    @IBOutlet weak var passwordLabel: UILabel!
    
    
    
    @objc func keyboardWasShow(notification: Notification) {  //настройка скролвью для маленьких экранов
        
        let info = notification.userInfo! as NSDictionary
        let kbSize = (info.value(forKey: UIResponder.keyboardFrameEndUserInfoKey) as! NSValue) .cgRectValue.size
        let contentInsets = UIEdgeInsets(top: 0.0, left: 0.0, bottom: kbSize.height, right: 0.0)
        
        self.scrollView?.contentInset = contentInsets
        scrollView?.scrollIndicatorInsets = contentInsets
    }
    
    @objc func keyboardWillBeHidden(notification: Notification) {
        let contentInsets = UIEdgeInsets.zero
        scrollView?.contentInset = contentInsets
    }
    
    override func viewWillAppear(_ animated: Bool) {  //подписка на уведомления
        super.viewWillAppear(animated)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWasShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillBeHidden(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {  //отписка от уведомлений
        super.viewWillDisappear(animated)
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    
    @IBAction func loginButtonPressed(_ sender: UIButton) {  //проверка логина/пароля
        self.checkPassword()
    }
    
    private func checkPassword() {
        let login = loginTextField.text
        let password = passwordTextField.text
        
        if login == "" && password == "" {
            loginTextField.backgroundColor = UIColor.green
            passwordTextField.backgroundColor = UIColor.green
            self.showAdmin()
        } else {
            loginTextField.backgroundColor = UIColor.red
            passwordTextField.backgroundColor = UIColor.red
            self.showAlert()
        }
    }
    
    
    func showAdmin() {    //пороль верный
        let storyBoard = UIStoryboard(name: "BaseViewController", bundle: nil)
        let viewController = storyBoard.instantiateInitialViewController()
        if let viewController = viewController as? BaseViewController {
            self.present(viewController, animated: true)
        }
    }
    
    func showAlert() {  //показ и конфигурация ошибки неверного пароля
        let alertController = UIAlertController(title: "Ошибка",
                                                message: "Неверный логин/пароль",
                                                preferredStyle: .alert)
        let action = UIAlertAction(title: "OK",
                                   style: .cancel)
        alertController.addAction(action)
        self.present(alertController, animated: true)
    }
    
    
    
    
    
    
    
}
