//
//  FriendsViewController.swift
//  VK
//
//  Created by Павел Власов on 08.10.2021.
//

import UIKit

class FriendsViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    let fromFriendsToGallerySegue = "fromFriendsToGallery"
    
    @IBOutlet weak var tableVIew: UITableView!
    
    var friendsArray = [Friend]()
    
    func fillFriendsArray() {                                                                                   //массив
        let friend1 = Friend(name: "Таурен", avatar: UIImage(named: "Таурен.png")!, photos: [UIImage(named: "Таурен.png")!,UIImage(named: "Ануб'арак.png")!,UIImage(named: "Сильвана.png")!, UIImage(named: "Дворф.png")!, UIImage(named: "Троль.png")!,UIImage(named: "Орче.png")!,UIImage(named: "Валь'шара.png")!])
        let friend2 = Friend(name: "Ануб'арак", avatar: UIImage(named: "Ануб'арак.png")!, photos: [UIImage(named: "Таурен.png")!,UIImage(named: "Ануб'арак.png")!,UIImage(named: "Сильвана.png")!, UIImage(named: "Дворф.png")!, UIImage(named: "Троль.png")!,UIImage(named: "Орче.png")!,UIImage(named: "Валь'шара.png")!])
        let friend3 = Friend(name: "Сильвана", avatar: UIImage(named: "Сильвана.png")!, photos: [UIImage(named: "Таурен.png")!,UIImage(named: "Ануб'арак.png")!,UIImage(named: "Сильвана.png")!, UIImage(named: "Дворф.png")!, UIImage(named: "Троль.png")!,UIImage(named: "Орче.png")!,UIImage(named: "Валь'шара.png")!])
        let friend4 = Friend(name: "Дворф", avatar: UIImage(named: "Дворф.png")!, photos: [UIImage(named: "Таурен.png")!,UIImage(named: "Ануб'арак.png")!,UIImage(named: "Сильвана.png")!, UIImage(named: "Дворф.png")!, UIImage(named: "Троль.png")!,UIImage(named: "Орче.png")!,UIImage(named: "Валь'шара.png")!])
        let friend5 = Friend(name: "Троль", avatar: UIImage(named: "Троль.png")!, photos: [UIImage(named: "Таурен.png")!,UIImage(named: "Ануб'арак.png")!,UIImage(named: "Сильвана.png")!, UIImage(named: "Дворф.png")!, UIImage(named: "Троль.png")!,UIImage(named: "Орче.png")!,UIImage(named: "Валь'шара.png")!])
        let friend6 = Friend(name: "Орче", avatar: UIImage(named: "Орче.png")!, photos: [UIImage(named: "Таурен.png")!,UIImage(named: "Ануб'арак.png")!,UIImage(named: "Сильвана.png")!, UIImage(named: "Дворф.png")!, UIImage(named: "Троль.png")!,UIImage(named: "Орче.png")!,UIImage(named: "Валь'шара.png")!])
        let friend7 = Friend(name: "Валь'шара", avatar: UIImage(named: "Валь'шара.png")!, photos: [UIImage(named: "Таурен.png")!,UIImage(named: "Ануб'арак.png")!,UIImage(named: "Сильвана.png")!, UIImage(named: "Дворф.png")!, UIImage(named: "Троль.png")!,UIImage(named: "Орче.png")!,UIImage(named: "Валь'шара.png")!])
        friendsArray.append(friend1)
        friendsArray.append(friend2)
        friendsArray.append(friend3)
        friendsArray.append(friend4)
        friendsArray.append(friend5)
        friendsArray.append(friend6)
        friendsArray.append(friend7)
    }
    
    func arrayLetter(sourceArray: [Friend]) -> [String] {
        var resultArray = [String]()
        for item in sourceArray {
            let nameLetter = String(item.name.prefix(1))
            if !resultArray.contains(nameLetter) {
                resultArray.append(nameLetter)
            }
        }
        return resultArray
    }
    
    func arrayByLetter(sourceArray: [Friend], letter: String) -> [Friend] {
        var resultArray = [Friend]()
        for item in sourceArray {
            let nameLetter = String(item.name.prefix(1))
            if nameLetter == letter {
                resultArray.append(item)
            }
        }
        return resultArray
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        let gradient = CAGradientLayer()  //создание градиента
        gradient.colors = [UIColor.systemPurple.cgColor,
                           UIColor.systemGreen.cgColor]  //цвета
        gradient.locations = [0, 1]  //где цвета
        gradient.startPoint = CGPoint.zero  //начало
        gradient.endPoint = CGPoint(x: 0, y: 1)  //конец
        gradient.frame = self.view.bounds
        gradient.zPosition = 0  //какой слой вью
        self.view.layer.addSublayer(gradient)
        
        tableVIew.layer.zPosition = 1
        
        fillFriendsArray()
        tableVIew.register(UINib(nibName: R.cell.one, bundle: nil), forCellReuseIdentifier: R.cell.one)
        tableVIew.delegate = self
        tableVIew.dataSource = self
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == fromFriendsToGallerySegue,
           let destinationVC = segue.destination as? GalleryViewController,
           let friend = sender as? Friend{
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {   //метод назначения высоты ячейки
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {    //метод вызываемый при нажатии на ячейку
        performSegue(withIdentifier: fromFriendsToGallerySegue, sender: friendsArray[indexPath.row]) //нормальный переход без опционала
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrayLetter(sourceArray: friendsArray).count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {   //колличество ячеек
        return arrayByLetter(sourceArray: friendsArray, letter: arrayLetter(sourceArray: friendsArray)[section]).count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: R.cell.one, for: indexPath) as! OneTableViewCell
        cell.configure(friend: arrayByLetter(sourceArray: friendsArray, letter: arrayLetter(sourceArray: friendsArray)[indexPath.section])[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return arrayLetter(sourceArray: friendsArray)[section].uppercased()
    }
    
}

struct Friend {
    var  name = String()
    var avatar = UIImage()
    var photos = [UIImage]()
    
}
