//
//  AllGroupViewController.swift
//  VK
//
//  Created by Павел Власов on 14.10.2021.
//

import UIKit

class AllGroupViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var selectedGroup: Group?
    
    var allGroupsArray = [Group]()
    func fillGroupsArray() {
        let group1 = Group(title: "Воин", avatar: UIImage(named: "Воин.png")!)
        let group2 = Group(title: "Друид", avatar: UIImage(named: "Друид.png")!)
        let group3 = Group(title: "Жрец", avatar: UIImage(named: "Жрец.png")!)
        let group4 = Group(title: "Маг", avatar: UIImage(named: "Маг.png")!)
        let group5 = Group(title: "Монах", avatar: UIImage(named: "Монах.png")!)
        let group6 = Group(title: "Охотник на демонов", avatar: UIImage(named: "Охотник на демонов.png")!)
        let group7 = Group(title: "Охотник", avatar: UIImage(named: "Охотник.png")!)
        let group8 = Group(title: "Паладин", avatar: UIImage(named: "Паладин.png")!)
        let group9 = Group(title: "Разбойник", avatar: UIImage(named: "Разбойник.png")!)
        let group10 = Group(title: "Рыцарь смерти", avatar: UIImage(named: "Рыцарь смерти.png")!)
        let group11 = Group(title: "Чернокнижник", avatar: UIImage(named: "Чернокнижник.png")!)
        let group12 = Group(title: "Шаман", avatar: UIImage(named: "Шаман.png")!)
        allGroupsArray.append(group1)
        allGroupsArray.append(group2)
        allGroupsArray.append(group3)
        allGroupsArray.append(group4)
        allGroupsArray.append(group5)
        allGroupsArray.append(group6)
        allGroupsArray.append(group7)
        allGroupsArray.append(group8)
        allGroupsArray.append(group9)
        allGroupsArray.append(group10)
        allGroupsArray.append(group11)
        allGroupsArray.append(group12)
        
    }
    
    
    
    
    @IBOutlet weak var allGroupTableView: UITableView!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allGroupsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celll = tableView.dequeueReusableCell(withIdentifier: R.cell.one, for: indexPath) as! OneTableViewCell
        celll.configure(group: allGroupsArray[indexPath.row])
        return celll
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedGroup = allGroupsArray[indexPath.row]
        performSegue(withIdentifier: fromAllGroupsToMyGroups, sender: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let gradient = CAGradientLayer()  //создание градиента
        gradient.colors = [UIColor.systemPurple.cgColor,
                           UIColor.systemGreen.cgColor]  //цвета
        gradient.locations = [0, 1]  //где цвета
        gradient.startPoint = CGPoint.zero  //начало
        gradient.endPoint = CGPoint(x: 0, y: 1)  //конец
        gradient.frame = self.view.bounds
        gradient.zPosition = 0  //какой слой вью
        self.view.layer.addSublayer(gradient)
        allGroupTableView.layer.zPosition = 1
        
        self.view.backgroundColor = UIColor.systemBackground
        fillGroupsArray()
        allGroupTableView.register(UINib(nibName: R.cell.one, bundle: nil), forCellReuseIdentifier: R.cell.one)
        allGroupTableView.delegate = self
        allGroupTableView.dataSource = self
        
    }
    
}
